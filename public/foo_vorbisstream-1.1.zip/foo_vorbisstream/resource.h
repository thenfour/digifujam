//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Dialogs.rc
//
#define IDI_ICON1                       101
#define ID_TRAYICON                     101
#define IDD_EDCAST_CONFIG               102
#define ID_STATUSPANE                   102
#define IDR_POPUP                       104
#define IDC_SHOWONSTARTUP               105
#define IDD_CONFIG                      105
#define IDD_PROPPAGE_LARGE              107
#define IDR_CONTEXT                     107
#define IDB_LIVE_ON                     109
#define IDB_LIVE_OFF                    110
#define IDB_LOGO                        115
#define IDB_SMALLLOGO                   124
#define IDR_SYSTRAY_MENU                130
#define ID_QUIT                         200
#define IDD_DIALOG1                     301
#define IDD_PROPPAGE_LARGE1             302
#define IDC_HIDE_BUTTON                 1000
#define IDC_EDIT_CONFIG                 1001
#define IDC_MANUALEDIT_METADATA         1002
#define IDC_DESTINATION_LOCATION        1004
#define IDC_KBPS_SENT                   1005
#define IDC_TAB1                        1005
#define IDC_BITRATE                     1006
#define IDC_METADATA                    1007
#define IDC_STATUS                      1008
#define IDC_QUALITY                     1008
#define IDC_SAMPLERATE                  1009
#define IDC_CHANNELS                    1010
#define IDC_SERVER_IP                   1013
#define IDC_SERVER_PORT                 1014
#define IDC_PASSWORD                    1015
#define IDC_MOUNTPOINT                  1016
#define IDC_SERVER_TYPE                 1017
#define IDC_ENCODER_TYPE                1018
#define IDC_PUBLIC                      1018
#define IDC_RECONNECTSECS               1019
#define IDC_STREAMNAME                  1019
#define IDC_STREAMDESC                  1020
#define IDC_LIVEREC                     1021
#define IDC_STREAMURL                   1021
#define IDC_STREAMGENRE                 1022
#define IDC_ICQ                         1023
#define IDC_AIM                         1024
#define IDC_LOGLEVEL                    1025
#define IDC_IRC                         1025
#define IDC_LOGFILE                     1026
#define IDC_RECDEVICES                  1027
#define IDC_RECVOLUME                   1028
#define IDC_AUTOCONNECT                 1029
#define IDC_RECCARDS                    1030
#define IDC_METER                       1044
#define IDC_LAMEPRESET                  1046
#define IDC_VUONOFF                     1047
#define IDC_STATIC_STATUS               1048
#define IDC_SHOWHIDE                    1049
#define IDC_REMOVESTRING                1055
#define IDC_BUTTON1                     1058
#define IDC_USEBITRATE                  1060
#define IDC_JOINTSTEREO                 1061
#define IDC_ST_RESTORE                  32771
#define IDC_ST_EXIT                     32772
#define ID__CONFIGURE                   40001
#define ID__CONNECT                     40002
#define ID_POPUP_CONNECT                40003
#define ID_POPUP_CONFIGURE              40004
#define ID_POPUP_DELETE                 40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
